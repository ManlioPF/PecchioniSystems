<?PHP

  echo "date()";
?>
