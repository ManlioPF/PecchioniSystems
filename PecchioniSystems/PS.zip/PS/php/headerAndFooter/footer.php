<!-- Footer -->
  <br><br><br>
  <footer class="py-2" style="left:0; bottom:0; width:100%; position:relative; background:rgba(0, 123, 255, 0); z-index: 1; ">
    <div class="container">
      <h5 class="m-0 text-center" style="color:gray">Creada Por: &copy;  &nbsp; &nbsp;| &nbsp; &nbsp; </h5>
    </div>
    <br>
  <!-- /.container -->
  </footer>
<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
